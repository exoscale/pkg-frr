#!/bin/sh

# This file exists to document the proper way to initialize autotools,
# and so that those used to the presence of bootstrap.sh or autogen.sh
# will have an eaiser time.

autoreconf -i
