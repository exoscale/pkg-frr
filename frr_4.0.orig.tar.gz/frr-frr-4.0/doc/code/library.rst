libfrr library facilities
=========================

.. toctree::
   :maxdepth: 2

   memtypes
   hooks


